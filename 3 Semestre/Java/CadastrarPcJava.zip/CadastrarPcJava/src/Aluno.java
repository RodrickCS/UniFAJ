public class Aluno {
    private String nome;
    private int RA;

    public Aluno(String nome, int RA) {
        this.nome = nome;
        this.RA = RA;
    }

    public String getNome() {
        return nome;
    }

    public int getRA() {
        return RA;
    }
}
