import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Computador> computadores = new ArrayList<>();
        Aluno aluno = new Aluno("Rodrigo Caetano Silva", 12326370);

        iniciarPrograma(sc, computadores, aluno);
    }
    private static void iniciarPrograma(Scanner sc, ArrayList<Computador> computadores, Aluno aluno) {
        int opcao;
        do {
            opcao = abrirMenu(sc);
            switch (opcao) {
                case 1:
                    cadastrarPc(sc, computadores);
                    break;
                case 2:
                    listarPc(computadores, sc);
                    break;
                case 3:
                    atualizarPc(computadores, sc);
                    break;
                case 4:
                    excluirPc(computadores, sc);
                    break;
                case 5:
                    alunoResponsavel(aluno, sc);
                    break;
                case 0:
                    System.out.println("Encerrando o programa...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
    }

    private static int abrirMenu(Scanner sc) {
        int opcao;
        System.out.println("Escolha uma opção:");
        System.out.println("1. Adicionar Computador");
        System.out.println("2. Listar Computadores");
        System.out.println("3. Atualizar Computador");
        System.out.println("4. Excluir Computador");
        System.out.println("5. Aluno responsável pelo código");
        System.out.println("0. Sair");
        opcao = sc.nextInt();
        sc.nextLine();
        return opcao;
    }

    private static void excluirPc(ArrayList<Computador> computadores, Scanner sc) {
        System.out.println("Digite o número do computador que deseja excluir:");
        int numeroPc = sc.nextInt();
        sc.nextLine();

        if (numeroPc >= 1 && numeroPc <= computadores.size()) {

            Computador pcRemovido = computadores.remove(numeroPc - 1);
            System.out.println("O computador abaixo foi removido:");
            System.out.println(pcRemovido);
        } else {
            System.out.println("Número de computador inválido!");
        }
    }
    private static void atualizarPc(ArrayList<Computador> computadores, Scanner sc) {

        System.out.println("Digite o número do computador que deseja atualizar:");
        int numeroPc = sc.nextInt();
        sc.nextLine();


        if (numeroPc >= 1 && numeroPc <= computadores.size()) {

            Computador pc = computadores.get(numeroPc - 1);


            System.out.println("Escolha o que deseja atualizar:");
            System.out.println("1. CPU");
            System.out.println("2. Memória");
            System.out.println("3. Armazenamento");
            System.out.println("4. Monitor");
            System.out.println("0. Voltar ao menu principal");
            int opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    System.out.println("Digite a nova CPU:");
                    String novaCpu = sc.nextLine();
                    pc.setCpu(novaCpu);
                    System.out.println("CPU atualizada com sucesso!");
                    break;
                case 2:
                    System.out.println("Digite a nova quantidade de memória:");
                    int novaMemoria = sc.nextInt();
                    pc.setMemoria(novaMemoria);
                    System.out.println("Memória atualizada com sucesso!");
                    break;
                case 3:
                    System.out.println("Digite o novo armazenamento:");
                    int novoArmazenamento = sc.nextInt();
                    pc.setArmazenamento(novoArmazenamento);
                    System.out.println("Armazenamento atualizado com sucesso!");
                    break;
                case 4:
                    System.out.println("Digite o novo monitor:");
                    String novoMonitor = sc.nextLine();
                    pc.setMonitor(novoMonitor);
                    System.out.println("Monitor atualizado com sucesso!");
                    break;
                case 0:
                    System.out.println("Voltando ao menu principal...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } else {
            System.out.println("Número de computador inválido!");
        }
        System.out.println("Pressione Enter para continuar...");
        sc.nextLine();
    }


    private static void listarPc(ArrayList<Computador> computadores, Scanner sc) {
        System.out.println("Lista de Computadores:");
        for (Computador pc : computadores) {
            System.out.println(pc);
        }
        System.out.println("Pressione Enter para continuar...");
        sc.nextLine();
    }

    private static void alunoResponsavel(Aluno aluno, Scanner sc) {
        System.out.println("Aluno responsável: " + aluno.getNome() + " - " + aluno.getRA());
        System.out.println("Pressione Enter para continuar...");
        sc.nextLine();
    }

    private static void cadastrarPc(Scanner sc, ArrayList<Computador> computadores) {
        System.out.println("CPU:");
        String cpuPC = sc.nextLine();
        System.out.println("Memória:");
        int memoriaPc = sc.nextInt();
        sc.nextLine();
        System.out.println("Armazenamento:");
        int armazenamentoPc = sc.nextInt();
        sc.nextLine();
        System.out.println("Monitor:");
        String monitorPc = sc.nextLine();
        Computador pc = new Computador(cpuPC, memoriaPc, armazenamentoPc, monitorPc);
        computadores.add(pc);
        System.out.println("Pc cadastrado !!! Pressione Enter para continuar... ");
        sc.nextLine();
    }
}
