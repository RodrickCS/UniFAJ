public class Computador {
    private static int proximoId = 1;
    private int id;
    private String cpu;
    private int memoria;
    private int armazenamento;
    private String monitor;

    public Computador(String cpu, int memoria, int armazenamento, String monitor) {
        this.id = proximoId++;
        this.cpu = cpu;
        this.memoria = memoria;
        this.armazenamento = armazenamento;
        this.monitor = monitor;
    }

    public Computador() {
    }
    public int getId() {
        return id;
    }

    public String getCpu() {
        return cpu;
    }

    public int getMemoria() {
        return memoria;
    }

    public int getArmazenamento() {
        return armazenamento;
    }

    public String getMonitor() {
        return monitor;
    }

    public static void setProximoId(int proximoId) {
        Computador.proximoId = proximoId;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public void setMemoria(int memoria) {
        this.memoria = memoria;
    }

    public void setArmazenamento(int armazenamento) {
        this.armazenamento = armazenamento;
    }

    public void setMonitor(String monitor) {
        this.monitor = monitor;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", CPU: " + cpu + ", Memória: " + memoria + "GB, Armazenamento: " + armazenamento + "GB, Monitor: " + monitor;
    }
}