package br.unifaj.Aula8RestauranteServer.Aula8RestauranteServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula8RestauranteServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula8RestauranteServerApplication.class, args);
	}

}
