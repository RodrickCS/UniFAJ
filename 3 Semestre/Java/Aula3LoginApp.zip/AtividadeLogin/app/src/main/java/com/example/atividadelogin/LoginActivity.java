package com.example.atividadelogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void login(View v) {
        Intent it = new Intent(this, HomeActivity.class);

        EditText usuario_input = findViewById(R.id.input_usuario);
        EditText senha_input = findViewById(R.id.input_senha);

        String usuarioText = usuario_input.getText().toString();
        String senhaText = senha_input.getText().toString();

        if (usuarioText.equals("aluno") && senhaText.equals("123456")) {
            it.putExtra("Usuario", usuarioText);
            startActivity(it);
        } else {
            Snackbar snackbar = Snackbar.make(v, "Usuário ou senha inválidos", Snackbar.LENGTH_LONG);
            snackbar.setAnchorView(findViewById(R.id.text_login));
            snackbar.show();
        }


    }

}